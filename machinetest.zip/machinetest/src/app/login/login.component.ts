import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm = new FormGroup({
    user: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  });
  constructor(private router: Router,
  ) {

  }


  ngOnInit(): void {


  }

  //method to login
  login() {
    if (this.loginForm.valid) {
      this.router.navigateByUrl('/main');
    }
    else {
      this.loginForm.markAllAsTouched();
    }
  }





}
