import { LoginComponent } from './login/login.component';

import { MainComponent } from './main/main.component';

export const APP_ROUTES = [
     
     
      {
        path: '',
        component: LoginComponent
      },
      {
        path: 'main',
        component: MainComponent
      },
      {
      path:'**',
      redirectTo: 'https://www.google.com/'
    }
]