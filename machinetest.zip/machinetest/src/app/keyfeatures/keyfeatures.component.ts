import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-keyfeatures',
  templateUrl: './keyfeatures.component.html',
  styleUrls: ['./keyfeatures.component.css']
})
export class KeyfeaturesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
