export const environment = {
  production: true,
  apiurl : "%apiUrl%",
  sessionCookieName: "%sessionCookieName%",
  cookieSuffix: "%cookieSuffix%",
  cookieDomain: "%cookieDomain%"
};
